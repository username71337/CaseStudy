﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;
using System.Data.SqlClient;

namespace CaseStudy
{
    
    public partial class memberRegistration : MetroForm
    {
        SqlConnection con;
        SqlDataReader rdr;
        SqlCommand cmd;
        public memberRegistration()
        {
            InitializeComponent();
        }

        private void memberRegistration_Load(object sender, EventArgs e)
        {
            SetConnection();
            membershipTypeTxt.DropDownStyle
                = ComboBoxStyle.DropDownList;
            //membershipTypeTxt.SelectedIndex = -1;
        }

        private void SetConnection()
        {
            con = new SqlConnection(@"Data source = RETARDLUL\SQLEXPRESS; Initial Catalog = CaseStudyDB; integrated security = true;");
        }

        private void registerBtn_Click(object sender, EventArgs e)
        {
            string member;
            member = membershipTypeTxt.Text;
            con.Open();
            cmd = new SqlCommand(@"INSERT INTO MEMBERS(memberName, joinDate, membershipType, memberUsername, memberPassword) VALUES('" + memberNameTxt.Text + "', '"+ DateTime.Now.ToString("yyyy'-'MM'-'dd' 'HH':'mm':'ss") + "','" + member + "', '" + memberUsernameTxt.Text + "', '" + memberPasswordTxt.Text + "');", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Registered successfully", "Success");
            ClearAll();
            memberForm2 memberForm2 = new memberForm2();
            memberForm2.Show();
            Visible = false;
        }

        private void ClearAll()
        {
            memberNameTxt.Clear();
            membershipTypeTxt.SelectedIndex = -1;
            memberUsernameTxt.Clear();
            memberPasswordTxt.Clear();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            memberForm2 form2 = new memberForm2();
            form2.Show();
            Visible = false;
        }
    }
}
