﻿namespace CaseStudy
{
    partial class memberPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.memberManagementTab = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.memberPasswordTxtBox = new System.Windows.Forms.TextBox();
            this.memberUsernameTxt = new System.Windows.Forms.TextBox();
            this.memberNameTxtBox = new System.Windows.Forms.TextBox();
            this.detailsUpdateBtn = new MetroFramework.Controls.MetroButton();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.membershipTypeLabel = new MetroFramework.Controls.MetroLabel();
            this.dateJoinedLabel = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.memberIDLabel = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.activityFeeTxt = new MetroFramework.Controls.MetroTextBox();
            this.activityNameTxt = new MetroFramework.Controls.MetroTextBox();
            this.activityIDTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.transactionBtn = new MetroFramework.Controls.MetroButton();
            this.memberActivityGrid = new MetroFramework.Controls.MetroGrid();
            this.activityID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activitySchedule = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityFee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityStaffID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityStaffName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityDuration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroTabPage4 = new MetroFramework.Controls.MetroTabPage();
            this.memberFinancialHistory = new MetroFramework.Controls.MetroGrid();
            this.transactionID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transactionDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transactionAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityIDTab3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transactionActivity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transactionMember = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memberIDTab3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metrotabpagef = new MetroFramework.Controls.MetroTabPage();
            this.IDtxtBox1 = new MetroFramework.Controls.MetroTextBox();
            this.cancelBtn = new MetroFramework.Controls.MetroButton();
            this.activityTrackingGrid = new MetroFramework.Controls.MetroGrid();
            this.activityID2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityStatusColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroTabPage5 = new MetroFramework.Controls.MetroTabPage();
            this.backBtn = new MetroFramework.Controls.MetroButton();
            this.memberManagementTab.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            this.metroTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.memberActivityGrid)).BeginInit();
            this.metroTabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.memberFinancialHistory)).BeginInit();
            this.metrotabpagef.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.activityTrackingGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // memberManagementTab
            // 
            this.memberManagementTab.Controls.Add(this.metroTabPage2);
            this.memberManagementTab.Controls.Add(this.metroTabPage3);
            this.memberManagementTab.Controls.Add(this.metroTabPage4);
            this.memberManagementTab.Controls.Add(this.metrotabpagef);
            this.memberManagementTab.Controls.Add(this.metroTabPage5);
            this.memberManagementTab.Location = new System.Drawing.Point(101, 96);
            this.memberManagementTab.Name = "memberManagementTab";
            this.memberManagementTab.SelectedIndex = 0;
            this.memberManagementTab.Size = new System.Drawing.Size(1098, 497);
            this.memberManagementTab.TabIndex = 1;
            this.memberManagementTab.UseSelectable = true;
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.memberPasswordTxtBox);
            this.metroTabPage2.Controls.Add(this.memberUsernameTxt);
            this.metroTabPage2.Controls.Add(this.memberNameTxtBox);
            this.metroTabPage2.Controls.Add(this.detailsUpdateBtn);
            this.metroTabPage2.Controls.Add(this.metroLabel6);
            this.metroTabPage2.Controls.Add(this.metroLabel5);
            this.metroTabPage2.Controls.Add(this.membershipTypeLabel);
            this.metroTabPage2.Controls.Add(this.dateJoinedLabel);
            this.metroTabPage2.Controls.Add(this.metroLabel2);
            this.metroTabPage2.Controls.Add(this.memberIDLabel);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(1090, 455);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "Member Details";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            // 
            // memberPasswordTxtBox
            // 
            this.memberPasswordTxtBox.Location = new System.Drawing.Point(467, 281);
            this.memberPasswordTxtBox.Name = "memberPasswordTxtBox";
            this.memberPasswordTxtBox.Size = new System.Drawing.Size(251, 22);
            this.memberPasswordTxtBox.TabIndex = 18;
            // 
            // memberUsernameTxt
            // 
            this.memberUsernameTxt.Enabled = false;
            this.memberUsernameTxt.Location = new System.Drawing.Point(467, 227);
            this.memberUsernameTxt.Name = "memberUsernameTxt";
            this.memberUsernameTxt.Size = new System.Drawing.Size(251, 22);
            this.memberUsernameTxt.TabIndex = 17;
            // 
            // memberNameTxtBox
            // 
            this.memberNameTxtBox.Location = new System.Drawing.Point(467, 175);
            this.memberNameTxtBox.Name = "memberNameTxtBox";
            this.memberNameTxtBox.Size = new System.Drawing.Size(251, 22);
            this.memberNameTxtBox.TabIndex = 16;
            // 
            // detailsUpdateBtn
            // 
            this.detailsUpdateBtn.Location = new System.Drawing.Point(525, 358);
            this.detailsUpdateBtn.Name = "detailsUpdateBtn";
            this.detailsUpdateBtn.Size = new System.Drawing.Size(75, 23);
            this.detailsUpdateBtn.TabIndex = 15;
            this.detailsUpdateBtn.Text = "Update";
            this.detailsUpdateBtn.UseSelectable = true;
            this.detailsUpdateBtn.Click += new System.EventHandler(this.detailsUpdateBtn_Click);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(391, 281);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(69, 20);
            this.metroLabel6.TabIndex = 14;
            this.metroLabel6.Text = "Password:";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(384, 227);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(76, 20);
            this.metroLabel5.TabIndex = 12;
            this.metroLabel5.Text = "Username:";
            // 
            // membershipTypeLabel
            // 
            this.membershipTypeLabel.AutoSize = true;
            this.membershipTypeLabel.Location = new System.Drawing.Point(336, 121);
            this.membershipTypeLabel.Name = "membershipTypeLabel";
            this.membershipTypeLabel.Size = new System.Drawing.Size(128, 20);
            this.membershipTypeLabel.TabIndex = 10;
            this.membershipTypeLabel.Text = "Membership Type: ";
            // 
            // dateJoinedLabel
            // 
            this.dateJoinedLabel.AutoSize = true;
            this.dateJoinedLabel.Location = new System.Drawing.Point(375, 73);
            this.dateJoinedLabel.Name = "dateJoinedLabel";
            this.dateJoinedLabel.Size = new System.Drawing.Size(89, 20);
            this.dateJoinedLabel.TabIndex = 8;
            this.dateJoinedLabel.Text = "Date Joined: ";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(353, 175);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(107, 20);
            this.metroLabel2.TabIndex = 6;
            this.metroLabel2.Text = "Member Name:";
            // 
            // memberIDLabel
            // 
            this.memberIDLabel.AutoSize = true;
            this.memberIDLabel.Location = new System.Drawing.Point(378, 32);
            this.memberIDLabel.Name = "memberIDLabel";
            this.memberIDLabel.Size = new System.Drawing.Size(86, 20);
            this.memberIDLabel.TabIndex = 4;
            this.memberIDLabel.Text = "Member ID: ";
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.activityFeeTxt);
            this.metroTabPage3.Controls.Add(this.activityNameTxt);
            this.metroTabPage3.Controls.Add(this.activityIDTxtBox);
            this.metroTabPage3.Controls.Add(this.transactionBtn);
            this.metroTabPage3.Controls.Add(this.memberActivityGrid);
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.HorizontalScrollbarSize = 10;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(1090, 455);
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Text = "Activities";
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            this.metroTabPage3.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.VerticalScrollbarSize = 10;
            // 
            // activityFeeTxt
            // 
            // 
            // 
            // 
            this.activityFeeTxt.CustomButton.Image = null;
            this.activityFeeTxt.CustomButton.Location = new System.Drawing.Point(67, 1);
            this.activityFeeTxt.CustomButton.Name = "";
            this.activityFeeTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.activityFeeTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.activityFeeTxt.CustomButton.TabIndex = 1;
            this.activityFeeTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.activityFeeTxt.CustomButton.UseSelectable = true;
            this.activityFeeTxt.CustomButton.Visible = false;
            this.activityFeeTxt.Enabled = false;
            this.activityFeeTxt.Lines = new string[0];
            this.activityFeeTxt.Location = new System.Drawing.Point(305, 302);
            this.activityFeeTxt.MaxLength = 32767;
            this.activityFeeTxt.Name = "activityFeeTxt";
            this.activityFeeTxt.PasswordChar = '\0';
            this.activityFeeTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.activityFeeTxt.SelectedText = "";
            this.activityFeeTxt.SelectionLength = 0;
            this.activityFeeTxt.SelectionStart = 0;
            this.activityFeeTxt.ShortcutsEnabled = true;
            this.activityFeeTxt.Size = new System.Drawing.Size(89, 23);
            this.activityFeeTxt.TabIndex = 6;
            this.activityFeeTxt.UseSelectable = true;
            this.activityFeeTxt.Visible = false;
            this.activityFeeTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.activityFeeTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // activityNameTxt
            // 
            // 
            // 
            // 
            this.activityNameTxt.CustomButton.Image = null;
            this.activityNameTxt.CustomButton.Location = new System.Drawing.Point(108, 1);
            this.activityNameTxt.CustomButton.Name = "";
            this.activityNameTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.activityNameTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.activityNameTxt.CustomButton.TabIndex = 1;
            this.activityNameTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.activityNameTxt.CustomButton.UseSelectable = true;
            this.activityNameTxt.CustomButton.Visible = false;
            this.activityNameTxt.Enabled = false;
            this.activityNameTxt.Lines = new string[0];
            this.activityNameTxt.Location = new System.Drawing.Point(491, 302);
            this.activityNameTxt.MaxLength = 32767;
            this.activityNameTxt.Name = "activityNameTxt";
            this.activityNameTxt.PasswordChar = '\0';
            this.activityNameTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.activityNameTxt.SelectedText = "";
            this.activityNameTxt.SelectionLength = 0;
            this.activityNameTxt.SelectionStart = 0;
            this.activityNameTxt.ShortcutsEnabled = true;
            this.activityNameTxt.Size = new System.Drawing.Size(130, 23);
            this.activityNameTxt.TabIndex = 5;
            this.activityNameTxt.UseSelectable = true;
            this.activityNameTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.activityNameTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // activityIDTxtBox
            // 
            // 
            // 
            // 
            this.activityIDTxtBox.CustomButton.Image = null;
            this.activityIDTxtBox.CustomButton.Location = new System.Drawing.Point(67, 1);
            this.activityIDTxtBox.CustomButton.Name = "";
            this.activityIDTxtBox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.activityIDTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.activityIDTxtBox.CustomButton.TabIndex = 1;
            this.activityIDTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.activityIDTxtBox.CustomButton.UseSelectable = true;
            this.activityIDTxtBox.CustomButton.Visible = false;
            this.activityIDTxtBox.Enabled = false;
            this.activityIDTxtBox.Lines = new string[0];
            this.activityIDTxtBox.Location = new System.Drawing.Point(74, 302);
            this.activityIDTxtBox.MaxLength = 32767;
            this.activityIDTxtBox.Name = "activityIDTxtBox";
            this.activityIDTxtBox.PasswordChar = '\0';
            this.activityIDTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.activityIDTxtBox.SelectedText = "";
            this.activityIDTxtBox.SelectionLength = 0;
            this.activityIDTxtBox.SelectionStart = 0;
            this.activityIDTxtBox.ShortcutsEnabled = true;
            this.activityIDTxtBox.Size = new System.Drawing.Size(89, 23);
            this.activityIDTxtBox.TabIndex = 4;
            this.activityIDTxtBox.UseSelectable = true;
            this.activityIDTxtBox.Visible = false;
            this.activityIDTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.activityIDTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // transactionBtn
            // 
            this.transactionBtn.Location = new System.Drawing.Point(525, 350);
            this.transactionBtn.Name = "transactionBtn";
            this.transactionBtn.Size = new System.Drawing.Size(75, 23);
            this.transactionBtn.TabIndex = 3;
            this.transactionBtn.Text = "buy";
            this.transactionBtn.UseSelectable = true;
            this.transactionBtn.Click += new System.EventHandler(this.transactionBtn_Click);
            // 
            // memberActivityGrid
            // 
            this.memberActivityGrid.AllowUserToAddRows = false;
            this.memberActivityGrid.AllowUserToDeleteRows = false;
            this.memberActivityGrid.AllowUserToResizeRows = false;
            this.memberActivityGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.memberActivityGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.memberActivityGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.memberActivityGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.memberActivityGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.memberActivityGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.memberActivityGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.activityID,
            this.Column1,
            this.activityDescription,
            this.activitySchedule,
            this.activityFee,
            this.activityStaffID,
            this.activityStaffName,
            this.activityDuration});
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.memberActivityGrid.DefaultCellStyle = dataGridViewCellStyle11;
            this.memberActivityGrid.EnableHeadersVisualStyles = false;
            this.memberActivityGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.memberActivityGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.memberActivityGrid.Location = new System.Drawing.Point(20, 34);
            this.memberActivityGrid.Name = "memberActivityGrid";
            this.memberActivityGrid.ReadOnly = true;
            this.memberActivityGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.memberActivityGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.memberActivityGrid.RowHeadersWidth = 51;
            this.memberActivityGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.memberActivityGrid.RowTemplate.Height = 24;
            this.memberActivityGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.memberActivityGrid.Size = new System.Drawing.Size(1058, 231);
            this.memberActivityGrid.TabIndex = 2;
            this.memberActivityGrid.SelectionChanged += new System.EventHandler(this.memberActivityGrid_SelectionChanged);
            // 
            // activityID
            // 
            this.activityID.HeaderText = "Activity ID";
            this.activityID.MinimumWidth = 6;
            this.activityID.Name = "activityID";
            this.activityID.ReadOnly = true;
            this.activityID.Width = 125;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Activity Name";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 125;
            // 
            // activityDescription
            // 
            this.activityDescription.HeaderText = "Description";
            this.activityDescription.MinimumWidth = 6;
            this.activityDescription.Name = "activityDescription";
            this.activityDescription.ReadOnly = true;
            this.activityDescription.Width = 125;
            // 
            // activitySchedule
            // 
            this.activitySchedule.HeaderText = "Schedule";
            this.activitySchedule.MinimumWidth = 6;
            this.activitySchedule.Name = "activitySchedule";
            this.activitySchedule.ReadOnly = true;
            this.activitySchedule.Width = 125;
            // 
            // activityFee
            // 
            this.activityFee.HeaderText = "Fee";
            this.activityFee.MinimumWidth = 6;
            this.activityFee.Name = "activityFee";
            this.activityFee.ReadOnly = true;
            this.activityFee.Width = 125;
            // 
            // activityStaffID
            // 
            this.activityStaffID.HeaderText = "Staff ID";
            this.activityStaffID.MinimumWidth = 6;
            this.activityStaffID.Name = "activityStaffID";
            this.activityStaffID.ReadOnly = true;
            this.activityStaffID.Width = 125;
            // 
            // activityStaffName
            // 
            this.activityStaffName.HeaderText = "Staff Name";
            this.activityStaffName.MinimumWidth = 6;
            this.activityStaffName.Name = "activityStaffName";
            this.activityStaffName.ReadOnly = true;
            this.activityStaffName.Width = 125;
            // 
            // activityDuration
            // 
            this.activityDuration.HeaderText = "Duration";
            this.activityDuration.MinimumWidth = 6;
            this.activityDuration.Name = "activityDuration";
            this.activityDuration.ReadOnly = true;
            this.activityDuration.Width = 125;
            // 
            // metroTabPage4
            // 
            this.metroTabPage4.Controls.Add(this.memberFinancialHistory);
            this.metroTabPage4.HorizontalScrollbarBarColor = true;
            this.metroTabPage4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.HorizontalScrollbarSize = 10;
            this.metroTabPage4.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage4.Name = "metroTabPage4";
            this.metroTabPage4.Size = new System.Drawing.Size(1090, 455);
            this.metroTabPage4.TabIndex = 3;
            this.metroTabPage4.Text = "Financial History";
            this.metroTabPage4.VerticalScrollbarBarColor = true;
            this.metroTabPage4.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.VerticalScrollbarSize = 10;
            // 
            // memberFinancialHistory
            // 
            this.memberFinancialHistory.AllowUserToAddRows = false;
            this.memberFinancialHistory.AllowUserToDeleteRows = false;
            this.memberFinancialHistory.AllowUserToResizeRows = false;
            this.memberFinancialHistory.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.memberFinancialHistory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.memberFinancialHistory.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.memberFinancialHistory.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.memberFinancialHistory.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.memberFinancialHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.memberFinancialHistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.transactionID,
            this.transactionDate,
            this.transactionAmount,
            this.activityIDTab3,
            this.transactionActivity,
            this.transactionMember,
            this.memberIDTab3});
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.memberFinancialHistory.DefaultCellStyle = dataGridViewCellStyle14;
            this.memberFinancialHistory.EnableHeadersVisualStyles = false;
            this.memberFinancialHistory.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.memberFinancialHistory.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.memberFinancialHistory.Location = new System.Drawing.Point(24, 37);
            this.memberFinancialHistory.Name = "memberFinancialHistory";
            this.memberFinancialHistory.ReadOnly = true;
            this.memberFinancialHistory.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.memberFinancialHistory.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.memberFinancialHistory.RowHeadersWidth = 51;
            this.memberFinancialHistory.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.memberFinancialHistory.RowTemplate.Height = 24;
            this.memberFinancialHistory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.memberFinancialHistory.Size = new System.Drawing.Size(1049, 318);
            this.memberFinancialHistory.TabIndex = 2;
            // 
            // transactionID
            // 
            this.transactionID.HeaderText = "Transaction ID";
            this.transactionID.MinimumWidth = 6;
            this.transactionID.Name = "transactionID";
            this.transactionID.ReadOnly = true;
            this.transactionID.Width = 125;
            // 
            // transactionDate
            // 
            this.transactionDate.HeaderText = "Date";
            this.transactionDate.MinimumWidth = 6;
            this.transactionDate.Name = "transactionDate";
            this.transactionDate.ReadOnly = true;
            this.transactionDate.Width = 125;
            // 
            // transactionAmount
            // 
            this.transactionAmount.HeaderText = "Amount";
            this.transactionAmount.MinimumWidth = 6;
            this.transactionAmount.Name = "transactionAmount";
            this.transactionAmount.ReadOnly = true;
            this.transactionAmount.Width = 125;
            // 
            // activityIDTab3
            // 
            this.activityIDTab3.HeaderText = "Acitivity ID";
            this.activityIDTab3.MinimumWidth = 6;
            this.activityIDTab3.Name = "activityIDTab3";
            this.activityIDTab3.ReadOnly = true;
            this.activityIDTab3.Width = 125;
            // 
            // transactionActivity
            // 
            this.transactionActivity.HeaderText = "Activity";
            this.transactionActivity.MinimumWidth = 6;
            this.transactionActivity.Name = "transactionActivity";
            this.transactionActivity.ReadOnly = true;
            this.transactionActivity.Width = 125;
            // 
            // transactionMember
            // 
            this.transactionMember.HeaderText = "Name";
            this.transactionMember.MinimumWidth = 6;
            this.transactionMember.Name = "transactionMember";
            this.transactionMember.ReadOnly = true;
            this.transactionMember.Width = 125;
            // 
            // memberIDTab3
            // 
            this.memberIDTab3.HeaderText = "Member ID";
            this.memberIDTab3.MinimumWidth = 6;
            this.memberIDTab3.Name = "memberIDTab3";
            this.memberIDTab3.ReadOnly = true;
            this.memberIDTab3.Width = 125;
            // 
            // metrotabpagef
            // 
            this.metrotabpagef.Controls.Add(this.IDtxtBox1);
            this.metrotabpagef.Controls.Add(this.cancelBtn);
            this.metrotabpagef.Controls.Add(this.activityTrackingGrid);
            this.metrotabpagef.HorizontalScrollbarBarColor = true;
            this.metrotabpagef.HorizontalScrollbarHighlightOnWheel = false;
            this.metrotabpagef.HorizontalScrollbarSize = 10;
            this.metrotabpagef.Location = new System.Drawing.Point(4, 38);
            this.metrotabpagef.Name = "metrotabpagef";
            this.metrotabpagef.Size = new System.Drawing.Size(1090, 455);
            this.metrotabpagef.TabIndex = 4;
            this.metrotabpagef.Text = "Activity Tracking";
            this.metrotabpagef.VerticalScrollbarBarColor = true;
            this.metrotabpagef.VerticalScrollbarHighlightOnWheel = false;
            this.metrotabpagef.VerticalScrollbarSize = 10;
            // 
            // IDtxtBox1
            // 
            // 
            // 
            // 
            this.IDtxtBox1.CustomButton.Image = null;
            this.IDtxtBox1.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.IDtxtBox1.CustomButton.Name = "";
            this.IDtxtBox1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.IDtxtBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.IDtxtBox1.CustomButton.TabIndex = 1;
            this.IDtxtBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.IDtxtBox1.CustomButton.UseSelectable = true;
            this.IDtxtBox1.CustomButton.Visible = false;
            this.IDtxtBox1.Enabled = false;
            this.IDtxtBox1.Lines = new string[0];
            this.IDtxtBox1.Location = new System.Drawing.Point(90, 234);
            this.IDtxtBox1.MaxLength = 32767;
            this.IDtxtBox1.Name = "IDtxtBox1";
            this.IDtxtBox1.PasswordChar = '\0';
            this.IDtxtBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.IDtxtBox1.SelectedText = "";
            this.IDtxtBox1.SelectionLength = 0;
            this.IDtxtBox1.SelectionStart = 0;
            this.IDtxtBox1.ShortcutsEnabled = true;
            this.IDtxtBox1.Size = new System.Drawing.Size(75, 23);
            this.IDtxtBox1.TabIndex = 4;
            this.IDtxtBox1.UseSelectable = true;
            this.IDtxtBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.IDtxtBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(525, 384);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(75, 23);
            this.cancelBtn.TabIndex = 3;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseSelectable = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // activityTrackingGrid
            // 
            this.activityTrackingGrid.AllowUserToAddRows = false;
            this.activityTrackingGrid.AllowUserToDeleteRows = false;
            this.activityTrackingGrid.AllowUserToResizeRows = false;
            this.activityTrackingGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.activityTrackingGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.activityTrackingGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.activityTrackingGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.activityTrackingGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.activityTrackingGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.activityTrackingGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.activityID2,
            this.activityColumn,
            this.activityStatusColumn});
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.activityTrackingGrid.DefaultCellStyle = dataGridViewCellStyle17;
            this.activityTrackingGrid.EnableHeadersVisualStyles = false;
            this.activityTrackingGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.activityTrackingGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.activityTrackingGrid.Location = new System.Drawing.Point(281, 46);
            this.activityTrackingGrid.Name = "activityTrackingGrid";
            this.activityTrackingGrid.ReadOnly = true;
            this.activityTrackingGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.activityTrackingGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.activityTrackingGrid.RowHeadersWidth = 51;
            this.activityTrackingGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.activityTrackingGrid.RowTemplate.Height = 24;
            this.activityTrackingGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.activityTrackingGrid.Size = new System.Drawing.Size(556, 306);
            this.activityTrackingGrid.TabIndex = 2;
            this.activityTrackingGrid.SelectionChanged += new System.EventHandler(this.activityTrackingGrid_SelectionChanged);
            // 
            // activityID2
            // 
            this.activityID2.HeaderText = "ID";
            this.activityID2.MinimumWidth = 6;
            this.activityID2.Name = "activityID2";
            this.activityID2.ReadOnly = true;
            this.activityID2.Width = 125;
            // 
            // activityColumn
            // 
            this.activityColumn.HeaderText = "Activity";
            this.activityColumn.MinimumWidth = 6;
            this.activityColumn.Name = "activityColumn";
            this.activityColumn.ReadOnly = true;
            this.activityColumn.Width = 125;
            // 
            // activityStatusColumn
            // 
            this.activityStatusColumn.HeaderText = "Status";
            this.activityStatusColumn.MinimumWidth = 6;
            this.activityStatusColumn.Name = "activityStatusColumn";
            this.activityStatusColumn.ReadOnly = true;
            this.activityStatusColumn.Width = 125;
            // 
            // metroTabPage5
            // 
            this.metroTabPage5.HorizontalScrollbarBarColor = true;
            this.metroTabPage5.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage5.HorizontalScrollbarSize = 10;
            this.metroTabPage5.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage5.Name = "metroTabPage5";
            this.metroTabPage5.Size = new System.Drawing.Size(1090, 455);
            this.metroTabPage5.TabIndex = 5;
            this.metroTabPage5.Text = "Preference Management";
            this.metroTabPage5.VerticalScrollbarBarColor = true;
            this.metroTabPage5.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage5.VerticalScrollbarSize = 10;
            // 
            // backBtn
            // 
            this.backBtn.Location = new System.Drawing.Point(630, 617);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(75, 23);
            this.backBtn.TabIndex = 2;
            this.backBtn.Text = "Back";
            this.backBtn.UseSelectable = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // memberPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1339, 673);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.memberManagementTab);
            this.Name = "memberPage";
            this.Text = "Member Page";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.memberPage_Load);
            this.memberManagementTab.ResumeLayout(false);
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            this.metroTabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.memberActivityGrid)).EndInit();
            this.metroTabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.memberFinancialHistory)).EndInit();
            this.metrotabpagef.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.activityTrackingGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl memberManagementTab;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private MetroFramework.Controls.MetroButton transactionBtn;
        private MetroFramework.Controls.MetroGrid memberActivityGrid;
        private MetroFramework.Controls.MetroTabPage metroTabPage4;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn activitySchedule;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityFee;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityStaffID;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityStaffName;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityDuration;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel membershipTypeLabel;
        private MetroFramework.Controls.MetroLabel dateJoinedLabel;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel memberIDLabel;
        private MetroFramework.Controls.MetroButton detailsUpdateBtn;
        private MetroFramework.Controls.MetroGrid memberFinancialHistory;
        private System.Windows.Forms.TextBox memberPasswordTxtBox;
        private System.Windows.Forms.TextBox memberUsernameTxt;
        private System.Windows.Forms.TextBox memberNameTxtBox;
        private MetroFramework.Controls.MetroTabPage metrotabpagef;
        private MetroFramework.Controls.MetroTabPage metroTabPage5;
        private MetroFramework.Controls.MetroGrid activityTrackingGrid;
        private MetroFramework.Controls.MetroTextBox activityFeeTxt;
        private MetroFramework.Controls.MetroTextBox activityNameTxt;
        private MetroFramework.Controls.MetroTextBox activityIDTxtBox;
        private MetroFramework.Controls.MetroButton cancelBtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityID2;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityStatusColumn;
        private MetroFramework.Controls.MetroTextBox IDtxtBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionID;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityIDTab3;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionActivity;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionMember;
        private System.Windows.Forms.DataGridViewTextBoxColumn memberIDTab3;
        private MetroFramework.Controls.MetroButton backBtn;
    }
}