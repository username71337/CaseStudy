﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;
using System.Data.SqlClient;

namespace CaseStudy
{
    public partial class StaffInfo : MetroForm
    {

        SqlConnection con;
        SqlDataReader rdr;
        SqlCommand cmd;

        public StaffInfo()
        {
            InitializeComponent();
        }

        private void StaffInfo_Load(object sender, EventArgs e)
        {
            SetConnection();
            LoadMembers();
            LoadStaff();
            LoadActivity();

            ClearAll();
            staffAddBtn.Enabled = true;
            staffUpdateBtn.Enabled = false;
        }

        private void LoadMembers()
        {
            memberInfo.Rows.Clear();
            con.Open();
            cmd = new SqlCommand(@"SELECT * FROM MEMBERS;", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                memberInfo.Rows.Add(rdr[0].ToString(),
                    rdr[1].ToString(), rdr[2].ToString(),
                    rdr[3].ToString(), rdr[4].ToString(), rdr[5].ToString(), rdr[6].ToString());
            }
            con.Close();
            ClearAll();
        }

        private void SetConnection()
        {
            con = new SqlConnection(@"Data source = RETARDLUL\SQLEXPRESS; Initial Catalog = CaseStudyDB; integrated security = true;");
        }

        private void LoadStaff()
        {
            staffData.Rows.Clear();
            staffGrid2.Rows.Clear();
            con.Open();
            cmd = new SqlCommand(@"SELECT * FROM STAFF;", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                staffData.Rows.Add(rdr[0].ToString(),
                    rdr[1].ToString(), rdr[2].ToString(),
                    rdr[3].ToString(), rdr[4].ToString(), rdr[5].ToString());

                staffGrid2.Rows.Add(rdr[0].ToString(),
                    rdr[1].ToString(), rdr[2].ToString(),
                    rdr[3].ToString(), rdr[4].ToString(), rdr[5].ToString());


            }
            con.Close();
            ClearAll();
        }

        private void staffAddBtn_Click(object sender, EventArgs e)
        {
            
            con.Open();
            cmd = new SqlCommand(@"INSERT INTO STAFF(staffName, shiftStart, shiftEnd, staffPosition, dateHired) VALUES('" + staffNameTxt.Text + "', '" + shiftStartTxt.Text + "', '" + shiftEndTxt.Text + "', '" + positionTxt.Text + "', '"+ DateTime.Now.ToString("yyyy'-'MM'-'dd' 'HH':'mm':'ss") + "');", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Staff added successfully", "Success");
            LoadStaff();
        }

        private void staffUpdateBtn_Click(object sender, EventArgs e)
        {
            if (staffData.SelectedRows.Count > 0)
            {
                con.Open();
                cmd = new SqlCommand(@"UPDATE STAFF
                    SET staffName = '" + staffNameTxt.Text
                    + "', shiftStart = '" + shiftStartTxt.Text
                    + "',  shiftEnd = '" + shiftEndTxt.Text
                    + "', staffPosition = '" + positionTxt.Text
                    + "' WHERE staffID = '" + Convert.ToInt32(staffIDTxt.Text) + "';", con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Staff details updated", "Success");
                LoadStaff();
            }
        }

        private void staffData_SelectionChanged(object sender, EventArgs e)
        {
            if (staffData.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = staffData.SelectedRows[0];
                staffIDTxt.Text = selectedRow.Cells[0].Value.ToString();
                staffNameTxt.Text = selectedRow.Cells[1].Value.ToString();
                shiftStartTxt.Text = selectedRow.Cells[2].Value.ToString();
                shiftEndTxt.Text = selectedRow.Cells[3].Value.ToString();
                positionTxt.Text = selectedRow.Cells[4].Value.ToString();
                dateHiredTxt.Text = selectedRow.Cells[5].Value.ToString();
                staffAddBtn.Enabled = false;
                staffUpdateBtn.Enabled = true;
            }
        }

        private void ClearAll()
        {
            staffIDTxt.Clear();
            staffNameTxt.Clear();
            shiftStartTxt.Clear();
            shiftEndTxt.Clear();
            positionTxt.Clear();
            dateHiredTxt.Clear();
            staffNameTxt2.Clear();
            staffIDTxt2.Clear();
            activityIDTxt.Clear();
            activityNameTxt.Clear();
            staffAddBtn.Enabled = true;
            staffUpdateBtn.Enabled = false;
        }

        private void staffClearBtn_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        private void LoadActivity()
        {
            memberActivityGrid.Rows.Clear();
            con.Open();
            cmd = new SqlCommand(@"SELECT * FROM ACTIVITIES;", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                memberActivityGrid.Rows.Add(rdr[0].ToString(),
                    rdr[1].ToString(), rdr[2].ToString(),
                    rdr[3].ToString(), rdr[4].ToString(), rdr[5].ToString(), rdr[6].ToString(), rdr[7].ToString());

            }
            con.Close();
        }

        private void staffGrid2_SelectionChanged(object sender, EventArgs e)
        {
            if (staffGrid2.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = staffGrid2.SelectedRows[0];
                staffIDTxt2.Text = selectedRow.Cells[0].Value.ToString();
                staffNameTxt2.Text = selectedRow.Cells[1].Value.ToString();
            }
        }

        private void memberActivityGrid_SelectionChanged(object sender, EventArgs e)
        {
            if (memberActivityGrid.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = memberActivityGrid.SelectedRows[0];
                activityIDTxt.Text = selectedRow.Cells[0].Value.ToString();
                activityNameTxt.Text = selectedRow.Cells[1].Value.ToString();
            }
        }

        private void assignBtn_Click(object sender, EventArgs e)
        {
            if (staffGrid2.SelectedRows.Count > 0 && memberActivityGrid.SelectedRows.Count > 0)
            {
                con.Open();
                cmd = new SqlCommand(@"UPDATE ACTIVITIES
                    SET staffID = '" + staffIDTxt2.Text
                    + "', activityStaffName = '" + staffNameTxt2.Text
                    + "' WHERE activityID = '" + Convert.ToInt32(activityIDTxt.Text) + "';", con);

                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Staff Assigned", "Success");
                LoadActivity();
            }
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            adminLogin adminLogin = new adminLogin();
            adminLogin.Show();
            Visible = false;
        }
    }

    }
