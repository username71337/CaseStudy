﻿namespace CaseStudy
{
    partial class StaffInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.staffClearBtn = new MetroFramework.Controls.MetroButton();
            this.dateHiredTxt = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.staffUpdateBtn = new MetroFramework.Controls.MetroButton();
            this.staffAddBtn = new MetroFramework.Controls.MetroButton();
            this.staffData = new MetroFramework.Controls.MetroGrid();
            this.staffID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.staffName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shiftStart = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shiftEnd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.position = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateHired = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionTxt = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.shiftStartTxt = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.shiftEndTxt = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.staffNameTxt = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.staffIDTxt = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.activityIDTxt = new MetroFramework.Controls.MetroTextBox();
            this.staffIDTxt2 = new MetroFramework.Controls.MetroTextBox();
            this.memberActivityGrid = new MetroFramework.Controls.MetroGrid();
            this.activityID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activitySchedule = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityFee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityStaffID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityStaffName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityDuration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityNameTxt = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.staffNameTxt2 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.assignBtn = new MetroFramework.Controls.MetroButton();
            this.staffGrid2 = new MetroFramework.Controls.MetroGrid();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.memberInfo = new MetroFramework.Controls.MetroGrid();
            this.memberID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memberName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateJoined = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memberPreference = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.membershipType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memberPassword = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memberUserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.backBtn = new MetroFramework.Controls.MetroButton();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.staffData)).BeginInit();
            this.metroTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.memberActivityGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffGrid2)).BeginInit();
            this.metroTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.memberInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage3);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Location = new System.Drawing.Point(23, 83);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(1415, 545);
            this.metroTabControl1.TabIndex = 0;
            this.metroTabControl1.UseSelectable = true;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.Controls.Add(this.staffClearBtn);
            this.metroTabPage1.Controls.Add(this.dateHiredTxt);
            this.metroTabPage1.Controls.Add(this.metroLabel6);
            this.metroTabPage1.Controls.Add(this.staffUpdateBtn);
            this.metroTabPage1.Controls.Add(this.staffAddBtn);
            this.metroTabPage1.Controls.Add(this.staffData);
            this.metroTabPage1.Controls.Add(this.positionTxt);
            this.metroTabPage1.Controls.Add(this.metroLabel5);
            this.metroTabPage1.Controls.Add(this.shiftStartTxt);
            this.metroTabPage1.Controls.Add(this.metroLabel4);
            this.metroTabPage1.Controls.Add(this.shiftEndTxt);
            this.metroTabPage1.Controls.Add(this.metroLabel3);
            this.metroTabPage1.Controls.Add(this.staffNameTxt);
            this.metroTabPage1.Controls.Add(this.metroLabel2);
            this.metroTabPage1.Controls.Add(this.staffIDTxt);
            this.metroTabPage1.Controls.Add(this.metroLabel1);
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 10;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(1407, 503);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "Staff Management";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 10;
            // 
            // staffClearBtn
            // 
            this.staffClearBtn.Location = new System.Drawing.Point(105, 370);
            this.staffClearBtn.Name = "staffClearBtn";
            this.staffClearBtn.Size = new System.Drawing.Size(75, 23);
            this.staffClearBtn.TabIndex = 17;
            this.staffClearBtn.Text = "Clear";
            this.staffClearBtn.UseSelectable = true;
            this.staffClearBtn.Click += new System.EventHandler(this.staffClearBtn_Click);
            // 
            // dateHiredTxt
            // 
            // 
            // 
            // 
            this.dateHiredTxt.CustomButton.Image = null;
            this.dateHiredTxt.CustomButton.Location = new System.Drawing.Point(113, 1);
            this.dateHiredTxt.CustomButton.Name = "";
            this.dateHiredTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.dateHiredTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.dateHiredTxt.CustomButton.TabIndex = 1;
            this.dateHiredTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.dateHiredTxt.CustomButton.UseSelectable = true;
            this.dateHiredTxt.CustomButton.Visible = false;
            this.dateHiredTxt.Enabled = false;
            this.dateHiredTxt.Lines = new string[0];
            this.dateHiredTxt.Location = new System.Drawing.Point(105, 235);
            this.dateHiredTxt.MaxLength = 32767;
            this.dateHiredTxt.Name = "dateHiredTxt";
            this.dateHiredTxt.PasswordChar = '\0';
            this.dateHiredTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dateHiredTxt.SelectedText = "";
            this.dateHiredTxt.SelectionLength = 0;
            this.dateHiredTxt.SelectionStart = 0;
            this.dateHiredTxt.ShortcutsEnabled = true;
            this.dateHiredTxt.Size = new System.Drawing.Size(135, 23);
            this.dateHiredTxt.TabIndex = 16;
            this.dateHiredTxt.UseSelectable = true;
            this.dateHiredTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.dateHiredTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(31, 238);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(76, 20);
            this.metroLabel6.TabIndex = 15;
            this.metroLabel6.Text = "Date Hired";
            // 
            // staffUpdateBtn
            // 
            this.staffUpdateBtn.Location = new System.Drawing.Point(150, 325);
            this.staffUpdateBtn.Name = "staffUpdateBtn";
            this.staffUpdateBtn.Size = new System.Drawing.Size(75, 23);
            this.staffUpdateBtn.TabIndex = 14;
            this.staffUpdateBtn.Text = "Update";
            this.staffUpdateBtn.UseSelectable = true;
            this.staffUpdateBtn.Click += new System.EventHandler(this.staffUpdateBtn_Click);
            // 
            // staffAddBtn
            // 
            this.staffAddBtn.Location = new System.Drawing.Point(59, 324);
            this.staffAddBtn.Name = "staffAddBtn";
            this.staffAddBtn.Size = new System.Drawing.Size(75, 23);
            this.staffAddBtn.TabIndex = 13;
            this.staffAddBtn.Text = "Add";
            this.staffAddBtn.UseSelectable = true;
            this.staffAddBtn.Click += new System.EventHandler(this.staffAddBtn_Click);
            // 
            // staffData
            // 
            this.staffData.AllowUserToAddRows = false;
            this.staffData.AllowUserToDeleteRows = false;
            this.staffData.AllowUserToResizeRows = false;
            this.staffData.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.staffData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.staffData.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.staffData.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.staffData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.staffData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.staffData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.staffID,
            this.staffName,
            this.shiftStart,
            this.shiftEnd,
            this.position,
            this.dateHired});
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.staffData.DefaultCellStyle = dataGridViewCellStyle14;
            this.staffData.EnableHeadersVisualStyles = false;
            this.staffData.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.staffData.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.staffData.Location = new System.Drawing.Point(273, 12);
            this.staffData.Name = "staffData";
            this.staffData.ReadOnly = true;
            this.staffData.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.staffData.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.staffData.RowHeadersWidth = 51;
            this.staffData.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.staffData.RowTemplate.Height = 24;
            this.staffData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.staffData.Size = new System.Drawing.Size(1064, 381);
            this.staffData.TabIndex = 12;
            this.staffData.SelectionChanged += new System.EventHandler(this.staffData_SelectionChanged);
            // 
            // staffID
            // 
            this.staffID.HeaderText = "ID";
            this.staffID.MinimumWidth = 6;
            this.staffID.Name = "staffID";
            this.staffID.ReadOnly = true;
            this.staffID.Width = 125;
            // 
            // staffName
            // 
            this.staffName.HeaderText = "Full Name";
            this.staffName.MinimumWidth = 6;
            this.staffName.Name = "staffName";
            this.staffName.ReadOnly = true;
            this.staffName.Width = 125;
            // 
            // shiftStart
            // 
            this.shiftStart.HeaderText = "Shift Start";
            this.shiftStart.MinimumWidth = 6;
            this.shiftStart.Name = "shiftStart";
            this.shiftStart.ReadOnly = true;
            this.shiftStart.Width = 125;
            // 
            // shiftEnd
            // 
            this.shiftEnd.HeaderText = "Shift End";
            this.shiftEnd.MinimumWidth = 6;
            this.shiftEnd.Name = "shiftEnd";
            this.shiftEnd.ReadOnly = true;
            this.shiftEnd.Width = 125;
            // 
            // position
            // 
            this.position.HeaderText = "Position";
            this.position.MinimumWidth = 6;
            this.position.Name = "position";
            this.position.ReadOnly = true;
            this.position.Width = 125;
            // 
            // dateHired
            // 
            this.dateHired.HeaderText = "Date Hired";
            this.dateHired.MinimumWidth = 6;
            this.dateHired.Name = "dateHired";
            this.dateHired.ReadOnly = true;
            this.dateHired.Width = 125;
            // 
            // positionTxt
            // 
            // 
            // 
            // 
            this.positionTxt.CustomButton.Image = null;
            this.positionTxt.CustomButton.Location = new System.Drawing.Point(113, 1);
            this.positionTxt.CustomButton.Name = "";
            this.positionTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.positionTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.positionTxt.CustomButton.TabIndex = 1;
            this.positionTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.positionTxt.CustomButton.UseSelectable = true;
            this.positionTxt.CustomButton.Visible = false;
            this.positionTxt.Lines = new string[0];
            this.positionTxt.Location = new System.Drawing.Point(105, 197);
            this.positionTxt.MaxLength = 32767;
            this.positionTxt.Name = "positionTxt";
            this.positionTxt.PasswordChar = '\0';
            this.positionTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.positionTxt.SelectedText = "";
            this.positionTxt.SelectionLength = 0;
            this.positionTxt.SelectionStart = 0;
            this.positionTxt.ShortcutsEnabled = true;
            this.positionTxt.Size = new System.Drawing.Size(135, 23);
            this.positionTxt.TabIndex = 11;
            this.positionTxt.UseSelectable = true;
            this.positionTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.positionTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(35, 200);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(56, 20);
            this.metroLabel5.TabIndex = 10;
            this.metroLabel5.Text = "Position";
            // 
            // shiftStartTxt
            // 
            // 
            // 
            // 
            this.shiftStartTxt.CustomButton.Image = null;
            this.shiftStartTxt.CustomButton.Location = new System.Drawing.Point(113, 1);
            this.shiftStartTxt.CustomButton.Name = "";
            this.shiftStartTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.shiftStartTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.shiftStartTxt.CustomButton.TabIndex = 1;
            this.shiftStartTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.shiftStartTxt.CustomButton.UseSelectable = true;
            this.shiftStartTxt.CustomButton.Visible = false;
            this.shiftStartTxt.Lines = new string[0];
            this.shiftStartTxt.Location = new System.Drawing.Point(105, 123);
            this.shiftStartTxt.MaxLength = 32767;
            this.shiftStartTxt.Name = "shiftStartTxt";
            this.shiftStartTxt.PasswordChar = '\0';
            this.shiftStartTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.shiftStartTxt.SelectedText = "";
            this.shiftStartTxt.SelectionLength = 0;
            this.shiftStartTxt.SelectionStart = 0;
            this.shiftStartTxt.ShortcutsEnabled = true;
            this.shiftStartTxt.Size = new System.Drawing.Size(135, 23);
            this.shiftStartTxt.TabIndex = 9;
            this.shiftStartTxt.UseSelectable = true;
            this.shiftStartTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.shiftStartTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(35, 126);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(67, 20);
            this.metroLabel4.TabIndex = 8;
            this.metroLabel4.Text = "Shift Start";
            // 
            // shiftEndTxt
            // 
            // 
            // 
            // 
            this.shiftEndTxt.CustomButton.Image = null;
            this.shiftEndTxt.CustomButton.Location = new System.Drawing.Point(113, 1);
            this.shiftEndTxt.CustomButton.Name = "";
            this.shiftEndTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.shiftEndTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.shiftEndTxt.CustomButton.TabIndex = 1;
            this.shiftEndTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.shiftEndTxt.CustomButton.UseSelectable = true;
            this.shiftEndTxt.CustomButton.Visible = false;
            this.shiftEndTxt.Lines = new string[0];
            this.shiftEndTxt.Location = new System.Drawing.Point(105, 162);
            this.shiftEndTxt.MaxLength = 32767;
            this.shiftEndTxt.Name = "shiftEndTxt";
            this.shiftEndTxt.PasswordChar = '\0';
            this.shiftEndTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.shiftEndTxt.SelectedText = "";
            this.shiftEndTxt.SelectionLength = 0;
            this.shiftEndTxt.SelectionStart = 0;
            this.shiftEndTxt.ShortcutsEnabled = true;
            this.shiftEndTxt.Size = new System.Drawing.Size(135, 23);
            this.shiftEndTxt.TabIndex = 7;
            this.shiftEndTxt.UseSelectable = true;
            this.shiftEndTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.shiftEndTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(35, 165);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(63, 20);
            this.metroLabel3.TabIndex = 6;
            this.metroLabel3.Text = "Shift End";
            // 
            // staffNameTxt
            // 
            // 
            // 
            // 
            this.staffNameTxt.CustomButton.Image = null;
            this.staffNameTxt.CustomButton.Location = new System.Drawing.Point(190, 1);
            this.staffNameTxt.CustomButton.Name = "";
            this.staffNameTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.staffNameTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.staffNameTxt.CustomButton.TabIndex = 1;
            this.staffNameTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.staffNameTxt.CustomButton.UseSelectable = true;
            this.staffNameTxt.CustomButton.Visible = false;
            this.staffNameTxt.Lines = new string[0];
            this.staffNameTxt.Location = new System.Drawing.Point(35, 82);
            this.staffNameTxt.MaxLength = 32767;
            this.staffNameTxt.Name = "staffNameTxt";
            this.staffNameTxt.PasswordChar = '\0';
            this.staffNameTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.staffNameTxt.SelectedText = "";
            this.staffNameTxt.SelectionLength = 0;
            this.staffNameTxt.SelectionStart = 0;
            this.staffNameTxt.ShortcutsEnabled = true;
            this.staffNameTxt.Size = new System.Drawing.Size(212, 23);
            this.staffNameTxt.TabIndex = 5;
            this.staffNameTxt.UseSelectable = true;
            this.staffNameTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.staffNameTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(34, 59);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(75, 20);
            this.metroLabel2.TabIndex = 4;
            this.metroLabel2.Text = "Full Name:";
            // 
            // staffIDTxt
            // 
            // 
            // 
            // 
            this.staffIDTxt.CustomButton.Image = null;
            this.staffIDTxt.CustomButton.Location = new System.Drawing.Point(99, 1);
            this.staffIDTxt.CustomButton.Name = "";
            this.staffIDTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.staffIDTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.staffIDTxt.CustomButton.TabIndex = 1;
            this.staffIDTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.staffIDTxt.CustomButton.UseSelectable = true;
            this.staffIDTxt.CustomButton.Visible = false;
            this.staffIDTxt.Enabled = false;
            this.staffIDTxt.Lines = new string[0];
            this.staffIDTxt.Location = new System.Drawing.Point(123, 21);
            this.staffIDTxt.MaxLength = 32767;
            this.staffIDTxt.Name = "staffIDTxt";
            this.staffIDTxt.PasswordChar = '\0';
            this.staffIDTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.staffIDTxt.SelectedText = "";
            this.staffIDTxt.SelectionLength = 0;
            this.staffIDTxt.SelectionStart = 0;
            this.staffIDTxt.ShortcutsEnabled = true;
            this.staffIDTxt.Size = new System.Drawing.Size(121, 23);
            this.staffIDTxt.TabIndex = 3;
            this.staffIDTxt.UseSelectable = true;
            this.staffIDTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.staffIDTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(35, 24);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(82, 20);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "ID Number:";
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.activityIDTxt);
            this.metroTabPage3.Controls.Add(this.staffIDTxt2);
            this.metroTabPage3.Controls.Add(this.memberActivityGrid);
            this.metroTabPage3.Controls.Add(this.activityNameTxt);
            this.metroTabPage3.Controls.Add(this.metroLabel8);
            this.metroTabPage3.Controls.Add(this.staffNameTxt2);
            this.metroTabPage3.Controls.Add(this.metroLabel7);
            this.metroTabPage3.Controls.Add(this.assignBtn);
            this.metroTabPage3.Controls.Add(this.staffGrid2);
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.HorizontalScrollbarSize = 10;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(1407, 503);
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Text = "Assignment";
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            this.metroTabPage3.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.VerticalScrollbarSize = 10;
            // 
            // activityIDTxt
            // 
            // 
            // 
            // 
            this.activityIDTxt.CustomButton.Image = null;
            this.activityIDTxt.CustomButton.Location = new System.Drawing.Point(19, 1);
            this.activityIDTxt.CustomButton.Name = "";
            this.activityIDTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.activityIDTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.activityIDTxt.CustomButton.TabIndex = 1;
            this.activityIDTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.activityIDTxt.CustomButton.UseSelectable = true;
            this.activityIDTxt.CustomButton.Visible = false;
            this.activityIDTxt.Enabled = false;
            this.activityIDTxt.Lines = new string[0];
            this.activityIDTxt.Location = new System.Drawing.Point(70, 283);
            this.activityIDTxt.MaxLength = 32767;
            this.activityIDTxt.Name = "activityIDTxt";
            this.activityIDTxt.PasswordChar = '\0';
            this.activityIDTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.activityIDTxt.SelectedText = "";
            this.activityIDTxt.SelectionLength = 0;
            this.activityIDTxt.SelectionStart = 0;
            this.activityIDTxt.ShortcutsEnabled = true;
            this.activityIDTxt.Size = new System.Drawing.Size(41, 23);
            this.activityIDTxt.TabIndex = 21;
            this.activityIDTxt.UseSelectable = true;
            this.activityIDTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.activityIDTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // staffIDTxt2
            // 
            // 
            // 
            // 
            this.staffIDTxt2.CustomButton.Image = null;
            this.staffIDTxt2.CustomButton.Location = new System.Drawing.Point(19, 1);
            this.staffIDTxt2.CustomButton.Name = "";
            this.staffIDTxt2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.staffIDTxt2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.staffIDTxt2.CustomButton.TabIndex = 1;
            this.staffIDTxt2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.staffIDTxt2.CustomButton.UseSelectable = true;
            this.staffIDTxt2.CustomButton.Visible = false;
            this.staffIDTxt2.Enabled = false;
            this.staffIDTxt2.Lines = new string[0];
            this.staffIDTxt2.Location = new System.Drawing.Point(70, 74);
            this.staffIDTxt2.MaxLength = 32767;
            this.staffIDTxt2.Name = "staffIDTxt2";
            this.staffIDTxt2.PasswordChar = '\0';
            this.staffIDTxt2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.staffIDTxt2.SelectedText = "";
            this.staffIDTxt2.SelectionLength = 0;
            this.staffIDTxt2.SelectionStart = 0;
            this.staffIDTxt2.ShortcutsEnabled = true;
            this.staffIDTxt2.Size = new System.Drawing.Size(41, 23);
            this.staffIDTxt2.TabIndex = 20;
            this.staffIDTxt2.UseSelectable = true;
            this.staffIDTxt2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.staffIDTxt2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // memberActivityGrid
            // 
            this.memberActivityGrid.AllowUserToAddRows = false;
            this.memberActivityGrid.AllowUserToDeleteRows = false;
            this.memberActivityGrid.AllowUserToResizeRows = false;
            this.memberActivityGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.memberActivityGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.memberActivityGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.memberActivityGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.memberActivityGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.memberActivityGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.memberActivityGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.activityID,
            this.Column1,
            this.activityDescription,
            this.activitySchedule,
            this.activityFee,
            this.activityStaffID,
            this.activityStaffName,
            this.activityDuration});
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.memberActivityGrid.DefaultCellStyle = dataGridViewCellStyle17;
            this.memberActivityGrid.EnableHeadersVisualStyles = false;
            this.memberActivityGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.memberActivityGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.memberActivityGrid.Location = new System.Drawing.Point(321, 269);
            this.memberActivityGrid.Name = "memberActivityGrid";
            this.memberActivityGrid.ReadOnly = true;
            this.memberActivityGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.memberActivityGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.memberActivityGrid.RowHeadersWidth = 51;
            this.memberActivityGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.memberActivityGrid.RowTemplate.Height = 24;
            this.memberActivityGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.memberActivityGrid.Size = new System.Drawing.Size(1017, 231);
            this.memberActivityGrid.TabIndex = 19;
            this.memberActivityGrid.SelectionChanged += new System.EventHandler(this.memberActivityGrid_SelectionChanged);
            // 
            // activityID
            // 
            this.activityID.HeaderText = "Activity ID";
            this.activityID.MinimumWidth = 6;
            this.activityID.Name = "activityID";
            this.activityID.ReadOnly = true;
            this.activityID.Width = 125;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Activity Name";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 125;
            // 
            // activityDescription
            // 
            this.activityDescription.HeaderText = "Description";
            this.activityDescription.MinimumWidth = 6;
            this.activityDescription.Name = "activityDescription";
            this.activityDescription.ReadOnly = true;
            this.activityDescription.Width = 125;
            // 
            // activitySchedule
            // 
            this.activitySchedule.HeaderText = "Schedule";
            this.activitySchedule.MinimumWidth = 6;
            this.activitySchedule.Name = "activitySchedule";
            this.activitySchedule.ReadOnly = true;
            this.activitySchedule.Width = 125;
            // 
            // activityFee
            // 
            this.activityFee.HeaderText = "Fee";
            this.activityFee.MinimumWidth = 6;
            this.activityFee.Name = "activityFee";
            this.activityFee.ReadOnly = true;
            this.activityFee.Width = 125;
            // 
            // activityStaffID
            // 
            this.activityStaffID.HeaderText = "Staff ID";
            this.activityStaffID.MinimumWidth = 6;
            this.activityStaffID.Name = "activityStaffID";
            this.activityStaffID.ReadOnly = true;
            this.activityStaffID.Width = 125;
            // 
            // activityStaffName
            // 
            this.activityStaffName.HeaderText = "Staff Name";
            this.activityStaffName.MinimumWidth = 6;
            this.activityStaffName.Name = "activityStaffName";
            this.activityStaffName.ReadOnly = true;
            this.activityStaffName.Width = 125;
            // 
            // activityDuration
            // 
            this.activityDuration.HeaderText = "Duration";
            this.activityDuration.MinimumWidth = 6;
            this.activityDuration.Name = "activityDuration";
            this.activityDuration.ReadOnly = true;
            this.activityDuration.Width = 125;
            // 
            // activityNameTxt
            // 
            // 
            // 
            // 
            this.activityNameTxt.CustomButton.Image = null;
            this.activityNameTxt.CustomButton.Location = new System.Drawing.Point(146, 1);
            this.activityNameTxt.CustomButton.Name = "";
            this.activityNameTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.activityNameTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.activityNameTxt.CustomButton.TabIndex = 1;
            this.activityNameTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.activityNameTxt.CustomButton.UseSelectable = true;
            this.activityNameTxt.CustomButton.Visible = false;
            this.activityNameTxt.Enabled = false;
            this.activityNameTxt.Lines = new string[0];
            this.activityNameTxt.Location = new System.Drawing.Point(70, 312);
            this.activityNameTxt.MaxLength = 32767;
            this.activityNameTxt.Name = "activityNameTxt";
            this.activityNameTxt.PasswordChar = '\0';
            this.activityNameTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.activityNameTxt.SelectedText = "";
            this.activityNameTxt.SelectionLength = 0;
            this.activityNameTxt.SelectionStart = 0;
            this.activityNameTxt.ShortcutsEnabled = true;
            this.activityNameTxt.Size = new System.Drawing.Size(168, 23);
            this.activityNameTxt.TabIndex = 18;
            this.activityNameTxt.UseSelectable = true;
            this.activityNameTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.activityNameTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(7, 312);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(56, 20);
            this.metroLabel8.TabIndex = 17;
            this.metroLabel8.Text = "Activity:";
            // 
            // staffNameTxt2
            // 
            // 
            // 
            // 
            this.staffNameTxt2.CustomButton.Image = null;
            this.staffNameTxt2.CustomButton.Location = new System.Drawing.Point(146, 1);
            this.staffNameTxt2.CustomButton.Name = "";
            this.staffNameTxt2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.staffNameTxt2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.staffNameTxt2.CustomButton.TabIndex = 1;
            this.staffNameTxt2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.staffNameTxt2.CustomButton.UseSelectable = true;
            this.staffNameTxt2.CustomButton.Visible = false;
            this.staffNameTxt2.Enabled = false;
            this.staffNameTxt2.Lines = new string[0];
            this.staffNameTxt2.Location = new System.Drawing.Point(70, 103);
            this.staffNameTxt2.MaxLength = 32767;
            this.staffNameTxt2.Name = "staffNameTxt2";
            this.staffNameTxt2.PasswordChar = '\0';
            this.staffNameTxt2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.staffNameTxt2.SelectedText = "";
            this.staffNameTxt2.SelectionLength = 0;
            this.staffNameTxt2.SelectionStart = 0;
            this.staffNameTxt2.ShortcutsEnabled = true;
            this.staffNameTxt2.Size = new System.Drawing.Size(168, 23);
            this.staffNameTxt2.TabIndex = 16;
            this.staffNameTxt2.UseSelectable = true;
            this.staffNameTxt2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.staffNameTxt2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(24, 103);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(39, 20);
            this.metroLabel7.TabIndex = 15;
            this.metroLabel7.Text = "Staff:";
            // 
            // assignBtn
            // 
            this.assignBtn.Location = new System.Drawing.Point(113, 437);
            this.assignBtn.Name = "assignBtn";
            this.assignBtn.Size = new System.Drawing.Size(75, 23);
            this.assignBtn.TabIndex = 14;
            this.assignBtn.Text = "Assign";
            this.assignBtn.UseSelectable = true;
            this.assignBtn.Click += new System.EventHandler(this.assignBtn_Click);
            // 
            // staffGrid2
            // 
            this.staffGrid2.AllowUserToAddRows = false;
            this.staffGrid2.AllowUserToDeleteRows = false;
            this.staffGrid2.AllowUserToResizeRows = false;
            this.staffGrid2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.staffGrid2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.staffGrid2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.staffGrid2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.staffGrid2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.staffGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.staffGrid2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.staffGrid2.DefaultCellStyle = dataGridViewCellStyle20;
            this.staffGrid2.EnableHeadersVisualStyles = false;
            this.staffGrid2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.staffGrid2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.staffGrid2.Location = new System.Drawing.Point(321, 23);
            this.staffGrid2.Name = "staffGrid2";
            this.staffGrid2.ReadOnly = true;
            this.staffGrid2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.staffGrid2.RowHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.staffGrid2.RowHeadersWidth = 51;
            this.staffGrid2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.staffGrid2.RowTemplate.Height = 24;
            this.staffGrid2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.staffGrid2.Size = new System.Drawing.Size(966, 179);
            this.staffGrid2.TabIndex = 13;
            this.staffGrid2.SelectionChanged += new System.EventHandler(this.staffGrid2_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Full Name";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Shift Start";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Shift End";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Position";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Date Hired";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.memberInfo);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(1407, 503);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "Members";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            // 
            // memberInfo
            // 
            this.memberInfo.AllowUserToAddRows = false;
            this.memberInfo.AllowUserToDeleteRows = false;
            this.memberInfo.AllowUserToResizeRows = false;
            this.memberInfo.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.memberInfo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.memberInfo.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.memberInfo.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.memberInfo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.memberInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.memberInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.memberID,
            this.memberName,
            this.dateJoined,
            this.memberPreference,
            this.membershipType,
            this.memberPassword,
            this.memberUserName});
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.memberInfo.DefaultCellStyle = dataGridViewCellStyle23;
            this.memberInfo.EnableHeadersVisualStyles = false;
            this.memberInfo.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.memberInfo.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.memberInfo.Location = new System.Drawing.Point(27, 38);
            this.memberInfo.Name = "memberInfo";
            this.memberInfo.ReadOnly = true;
            this.memberInfo.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.memberInfo.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.memberInfo.RowHeadersWidth = 51;
            this.memberInfo.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.memberInfo.RowTemplate.Height = 24;
            this.memberInfo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.memberInfo.Size = new System.Drawing.Size(1320, 469);
            this.memberInfo.TabIndex = 2;
            // 
            // memberID
            // 
            this.memberID.HeaderText = "ID";
            this.memberID.MinimumWidth = 6;
            this.memberID.Name = "memberID";
            this.memberID.ReadOnly = true;
            this.memberID.Width = 125;
            // 
            // memberName
            // 
            this.memberName.HeaderText = "Name";
            this.memberName.MinimumWidth = 6;
            this.memberName.Name = "memberName";
            this.memberName.ReadOnly = true;
            this.memberName.Width = 125;
            // 
            // dateJoined
            // 
            this.dateJoined.HeaderText = "Date Joined";
            this.dateJoined.MinimumWidth = 6;
            this.dateJoined.Name = "dateJoined";
            this.dateJoined.ReadOnly = true;
            this.dateJoined.Width = 125;
            // 
            // memberPreference
            // 
            this.memberPreference.HeaderText = "Preference";
            this.memberPreference.MinimumWidth = 6;
            this.memberPreference.Name = "memberPreference";
            this.memberPreference.ReadOnly = true;
            this.memberPreference.Width = 125;
            // 
            // membershipType
            // 
            this.membershipType.HeaderText = "Membership Type";
            this.membershipType.MinimumWidth = 6;
            this.membershipType.Name = "membershipType";
            this.membershipType.ReadOnly = true;
            this.membershipType.Width = 125;
            // 
            // memberPassword
            // 
            this.memberPassword.HeaderText = "Member Password";
            this.memberPassword.MinimumWidth = 6;
            this.memberPassword.Name = "memberPassword";
            this.memberPassword.ReadOnly = true;
            this.memberPassword.Width = 125;
            // 
            // memberUserName
            // 
            this.memberUserName.HeaderText = "Username";
            this.memberUserName.MinimumWidth = 6;
            this.memberUserName.Name = "memberUserName";
            this.memberUserName.ReadOnly = true;
            this.memberUserName.Width = 125;
            // 
            // backBtn
            // 
            this.backBtn.Location = new System.Drawing.Point(770, 663);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(75, 23);
            this.backBtn.TabIndex = 1;
            this.backBtn.Text = "Back";
            this.backBtn.UseSelectable = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // StaffInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1476, 709);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.metroTabControl1);
            this.Name = "StaffInfo";
            this.Text = "Employee Management Form";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.StaffInfo_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.staffData)).EndInit();
            this.metroTabPage3.ResumeLayout(false);
            this.metroTabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.memberActivityGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffGrid2)).EndInit();
            this.metroTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.memberInfo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTextBox shiftStartTxt;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroTextBox shiftEndTxt;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox staffNameTxt;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox staffIDTxt;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroGrid staffData;
        private MetroFramework.Controls.MetroTextBox positionTxt;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroButton staffUpdateBtn;
        private MetroFramework.Controls.MetroButton staffAddBtn;
        private MetroFramework.Controls.MetroTextBox dateHiredTxt;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.DataGridViewTextBoxColumn staffID;
        private System.Windows.Forms.DataGridViewTextBoxColumn staffName;
        private System.Windows.Forms.DataGridViewTextBoxColumn shiftStart;
        private System.Windows.Forms.DataGridViewTextBoxColumn shiftEnd;
        private System.Windows.Forms.DataGridViewTextBoxColumn position;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateHired;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroGrid memberInfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn memberID;
        private System.Windows.Forms.DataGridViewTextBoxColumn memberName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateJoined;
        private System.Windows.Forms.DataGridViewTextBoxColumn memberPreference;
        private System.Windows.Forms.DataGridViewTextBoxColumn membershipType;
        private System.Windows.Forms.DataGridViewTextBoxColumn memberPassword;
        private System.Windows.Forms.DataGridViewTextBoxColumn memberUserName;
        private MetroFramework.Controls.MetroButton staffClearBtn;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private MetroFramework.Controls.MetroGrid staffGrid2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private MetroFramework.Controls.MetroTextBox activityNameTxt;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroTextBox staffNameTxt2;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroButton assignBtn;
        private MetroFramework.Controls.MetroGrid memberActivityGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn activitySchedule;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityFee;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityStaffID;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityStaffName;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityDuration;
        private MetroFramework.Controls.MetroTextBox activityIDTxt;
        private MetroFramework.Controls.MetroTextBox staffIDTxt2;
        private MetroFramework.Controls.MetroButton backBtn;
    }
}