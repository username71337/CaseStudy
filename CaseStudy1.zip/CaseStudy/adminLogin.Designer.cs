﻿namespace CaseStudy
{
    partial class adminLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.adminUsername = new MetroFramework.Controls.MetroTextBox();
            this.adminPassword = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.adminLoginBtn = new MetroFramework.Controls.MetroButton();
            this.backBtn = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(431, 174);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(76, 20);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "Username:";
            // 
            // adminUsername
            // 
            // 
            // 
            // 
            this.adminUsername.CustomButton.Image = null;
            this.adminUsername.CustomButton.Location = new System.Drawing.Point(165, 1);
            this.adminUsername.CustomButton.Name = "";
            this.adminUsername.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.adminUsername.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.adminUsername.CustomButton.TabIndex = 1;
            this.adminUsername.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.adminUsername.CustomButton.UseSelectable = true;
            this.adminUsername.CustomButton.Visible = false;
            this.adminUsername.Lines = new string[0];
            this.adminUsername.Location = new System.Drawing.Point(431, 197);
            this.adminUsername.MaxLength = 32767;
            this.adminUsername.Name = "adminUsername";
            this.adminUsername.PasswordChar = '\0';
            this.adminUsername.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.adminUsername.SelectedText = "";
            this.adminUsername.SelectionLength = 0;
            this.adminUsername.SelectionStart = 0;
            this.adminUsername.ShortcutsEnabled = true;
            this.adminUsername.Size = new System.Drawing.Size(187, 23);
            this.adminUsername.TabIndex = 1;
            this.adminUsername.UseSelectable = true;
            this.adminUsername.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.adminUsername.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // adminPassword
            // 
            // 
            // 
            // 
            this.adminPassword.CustomButton.Image = null;
            this.adminPassword.CustomButton.Location = new System.Drawing.Point(164, 1);
            this.adminPassword.CustomButton.Name = "";
            this.adminPassword.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.adminPassword.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.adminPassword.CustomButton.TabIndex = 1;
            this.adminPassword.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.adminPassword.CustomButton.UseSelectable = true;
            this.adminPassword.CustomButton.Visible = false;
            this.adminPassword.Lines = new string[0];
            this.adminPassword.Location = new System.Drawing.Point(432, 315);
            this.adminPassword.MaxLength = 32767;
            this.adminPassword.Name = "adminPassword";
            this.adminPassword.PasswordChar = '*';
            this.adminPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.adminPassword.SelectedText = "";
            this.adminPassword.SelectionLength = 0;
            this.adminPassword.SelectionStart = 0;
            this.adminPassword.ShortcutsEnabled = true;
            this.adminPassword.Size = new System.Drawing.Size(186, 23);
            this.adminPassword.TabIndex = 3;
            this.adminPassword.UseSelectable = true;
            this.adminPassword.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.adminPassword.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(431, 292);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(69, 20);
            this.metroLabel2.TabIndex = 2;
            this.metroLabel2.Text = "Password:";
            // 
            // adminLoginBtn
            // 
            this.adminLoginBtn.Location = new System.Drawing.Point(483, 401);
            this.adminLoginBtn.Name = "adminLoginBtn";
            this.adminLoginBtn.Size = new System.Drawing.Size(75, 23);
            this.adminLoginBtn.TabIndex = 4;
            this.adminLoginBtn.Text = "Login";
            this.adminLoginBtn.UseSelectable = true;
            this.adminLoginBtn.Click += new System.EventHandler(this.adminLoginBtn_Click);
            // 
            // backBtn
            // 
            this.backBtn.Location = new System.Drawing.Point(483, 451);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(75, 23);
            this.backBtn.TabIndex = 5;
            this.backBtn.Text = "Back";
            this.backBtn.UseSelectable = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // adminLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 576);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.adminLoginBtn);
            this.Controls.Add(this.adminPassword);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.adminUsername);
            this.Controls.Add(this.metroLabel1);
            this.Name = "adminLogin";
            this.Text = "Admin Login";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.adminLogin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox adminUsername;
        private MetroFramework.Controls.MetroTextBox adminPassword;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroButton adminLoginBtn;
        private MetroFramework.Controls.MetroButton backBtn;
    }
}