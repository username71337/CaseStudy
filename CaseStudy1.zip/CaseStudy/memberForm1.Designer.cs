﻿namespace CaseStudy
{
    partial class memberForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.memberLoginBtn = new MetroFramework.Controls.MetroButton();
            this.loginUsernameTxt = new System.Windows.Forms.TextBox();
            this.loginPasswordTxt = new System.Windows.Forms.TextBox();
            this.backBtn = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(513, 333);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(69, 20);
            this.metroLabel2.TabIndex = 7;
            this.metroLabel2.Text = "Password:";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(506, 225);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(76, 20);
            this.metroLabel1.TabIndex = 6;
            this.metroLabel1.Text = "Username:";
            // 
            // memberLoginBtn
            // 
            this.memberLoginBtn.Location = new System.Drawing.Point(640, 443);
            this.memberLoginBtn.Name = "memberLoginBtn";
            this.memberLoginBtn.Size = new System.Drawing.Size(75, 23);
            this.memberLoginBtn.TabIndex = 5;
            this.memberLoginBtn.TabStop = false;
            this.memberLoginBtn.Text = "Login";
            this.memberLoginBtn.UseSelectable = true;
            this.memberLoginBtn.Click += new System.EventHandler(this.memberLoginBtn_Click_1);
            // 
            // loginUsernameTxt
            // 
            this.loginUsernameTxt.Location = new System.Drawing.Point(589, 222);
            this.loginUsernameTxt.Name = "loginUsernameTxt";
            this.loginUsernameTxt.Size = new System.Drawing.Size(230, 22);
            this.loginUsernameTxt.TabIndex = 8;
            // 
            // loginPasswordTxt
            // 
            this.loginPasswordTxt.Location = new System.Drawing.Point(589, 333);
            this.loginPasswordTxt.Name = "loginPasswordTxt";
            this.loginPasswordTxt.PasswordChar = '*';
            this.loginPasswordTxt.Size = new System.Drawing.Size(230, 22);
            this.loginPasswordTxt.TabIndex = 9;
            // 
            // backBtn
            // 
            this.backBtn.Location = new System.Drawing.Point(640, 493);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(75, 23);
            this.backBtn.TabIndex = 10;
            this.backBtn.Text = "Back";
            this.backBtn.UseSelectable = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // memberForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1347, 693);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.loginPasswordTxt);
            this.Controls.Add(this.loginUsernameTxt);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.memberLoginBtn);
            this.Name = "memberForm1";
            this.Text = "Member Login";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.memberForm1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroButton memberLoginBtn;
        private System.Windows.Forms.TextBox loginUsernameTxt;
        private System.Windows.Forms.TextBox loginPasswordTxt;
        private MetroFramework.Controls.MetroButton backBtn;
    }
}