﻿namespace CaseStudy
{
    partial class memberForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.memberLoginBtn = new MetroFramework.Controls.MetroButton();
            this.memberRegisterBtn = new MetroFramework.Controls.MetroButton();
            this.backBtn = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // memberLoginBtn
            // 
            this.memberLoginBtn.Location = new System.Drawing.Point(304, 194);
            this.memberLoginBtn.Name = "memberLoginBtn";
            this.memberLoginBtn.Size = new System.Drawing.Size(159, 66);
            this.memberLoginBtn.TabIndex = 0;
            this.memberLoginBtn.TabStop = false;
            this.memberLoginBtn.Text = "Login";
            this.memberLoginBtn.UseSelectable = true;
            this.memberLoginBtn.Click += new System.EventHandler(this.memberLoginBtn_Click);
            // 
            // memberRegisterBtn
            // 
            this.memberRegisterBtn.Location = new System.Drawing.Point(589, 194);
            this.memberRegisterBtn.Name = "memberRegisterBtn";
            this.memberRegisterBtn.Size = new System.Drawing.Size(159, 66);
            this.memberRegisterBtn.TabIndex = 1;
            this.memberRegisterBtn.TabStop = false;
            this.memberRegisterBtn.Text = "Register";
            this.memberRegisterBtn.UseSelectable = true;
            this.memberRegisterBtn.Click += new System.EventHandler(this.memberRegisterBtn_Click);
            // 
            // backBtn
            // 
            this.backBtn.Location = new System.Drawing.Point(491, 390);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(75, 23);
            this.backBtn.TabIndex = 2;
            this.backBtn.TabStop = false;
            this.backBtn.Text = "Back";
            this.backBtn.UseSelectable = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // memberForm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1057, 463);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.memberRegisterBtn);
            this.Controls.Add(this.memberLoginBtn);
            this.Name = "memberForm2";
            this.Text = "Login/Register";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroButton memberLoginBtn;
        private MetroFramework.Controls.MetroButton memberRegisterBtn;
        private MetroFramework.Controls.MetroButton backBtn;
    }
}