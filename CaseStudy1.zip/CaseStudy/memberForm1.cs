﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace CaseStudy
{
    public partial class memberForm1 : MetroForm
    {
        SqlConnection con =  new SqlConnection(@"Data source = RETARDLUL\SQLEXPRESS; Initial Catalog = CaseStudyDB; integrated security = true;");
        SqlDataReader rdr;
        SqlCommand cmd;


        public memberForm1()
        {
            InitializeComponent();
        }

        private void memberForm1_Load(object sender, EventArgs e)
        {

        }

        public static string username = "";
        public static string password = "";
        string s1;
        string p1;
        

        private void memberLoginBtn_Click_1(object sender, EventArgs e)
        {
            
            con.Open();
            cmd = new SqlCommand(@"SELECT memberUsername, memberPassword FROM MEMBERS WHERE memberUsername = '"+loginUsernameTxt.Text+"' AND memberPassword = '"+loginPasswordTxt.Text+"';", con);
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                s1 = rdr[0].ToString();
                p1 = rdr[1].ToString();
            }
            con.Close();

            if (loginUsernameTxt.Text == s1 && loginPasswordTxt.Text == p1)
            {

                username = s1;
                password = p1;
                memberPage memberPage = new memberPage();
                MessageBox.Show("Login Successful", "Success");
                memberPage.Show();
                Visible = false;
               
            }
            else
            {
                MessageBox.Show("Incorrect Username or Password");
            }

        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            memberForm2 memberForm2 = new memberForm2();
            memberForm2.Show();
            Visible = false;
        }
    }
}
